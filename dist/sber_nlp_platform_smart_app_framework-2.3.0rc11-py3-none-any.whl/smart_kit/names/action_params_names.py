TO_MESSAGE_PARAMS = "to_message_params"
TO_MESSAGE_NAME = "to_message_name"
SAVED_MESSAGES = "saved_messages"
SEND_TIMESTAMP = "send_timestamp"
