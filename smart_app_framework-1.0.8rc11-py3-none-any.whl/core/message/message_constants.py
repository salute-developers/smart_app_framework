MSG_USERID_KEY = "userId"
MSG_CHATID_KEY = "chatId"
MSG_MESSAGEID_KEY = "messageId"
MSG_USERCHANNEL_KEY = "userChannel"
