CALLBACK_ID_HEADER = "app_callback_id"
LINK_BEHAVIOR_FLAG = "link_previous_behavior"
KAFKA = "kafka"
