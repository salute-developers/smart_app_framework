class CephIOMaxRetryReached(Exception):
    pass


class CephIOFileNotFoundException(FileNotFoundError):
    pass
