

class Filter:
    def __init__(self, items):
        pass

    def filter_out(self, data, user, params=None):
        return data
