# coding: utf-8
import unittest


class SettingsTest1(unittest.TestCase):
    def test_Settings(self):
        pass
