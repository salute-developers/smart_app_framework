PROFILE_DATA = "profile_data"
STATUS_CODE = "status_code"
CODE = "code"
GEO = "geo"
